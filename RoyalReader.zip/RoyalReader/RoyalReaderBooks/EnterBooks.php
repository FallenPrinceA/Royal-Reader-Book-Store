<!DOCTYPE HTML>
<html>
<head>
<title>Enter Form for Book Store</title>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
        <link href="RoyalReadHomePage.css" rel="stylesheet" type="text/css">
</head>
<body>
 <!--Top Image Banner-->
 <div class="ImageFile">
    <h1 style="text-align: center">Royal Reader Book Store</h1>
  </div>
  <!--Top Image Banner Ends-->
 <!-- Navigation Bar Starts -->
  <div id="container">
  <ul id="nav">
  <li class="odd"><a href="../RoyalReaderHomePageL.php">Home Page</a></li>
  <li class="even"><a href="EnterBooks.php">Add a New Book</a></li>
  <li class="odd"><a href="DisplayBooks.php">RoyalReader Catalog</a></li>
  <li class="even"><a href="../SimpleBooks/index.php">Manual Shopping Cart</a></li>
</ul>
</div>
<center><h2>Royal Reader Book Store</h2></center>
<!--Once the form is submitted, all the form data is forwarded to InsertBooks.php -->
<form action="InsertBooks.php" method="post">

<table border="2" align="center" cellpadding="5" cellspacing="5">
<tr>
<td> Enter Title:</td>
<td> <input type="text" name="title" id="title"> </td>
</tr>
<tr>
<td> Enter Author:</td>
<td> <input type="text" name="author" id="author"> </td>
</tr>
<tr>
<td> Enter Published Date:</td>
<td> <input type="date" name="pubdate" id="pubdate"> </td>
</tr>
<tr>
<td> Enter Price:</td>
<td> <input type="currency" name="price" id="price"> </td>
</tr>
<tr>
<td> Enter Synopsis: </td>
<td> <textarea type="text" name="synopsis" id="synopsis" rows="10" cols="80"> Please do not include Discord, Social Media, Patreon or PayPal links here; this will get your submission rejected.</textarea></td>
</tr>
<tr>
<td> Enter Publisher:</td>
<td> <input type="text" name="publisher" id="publisher"> </td>
</tr>
<tr>
<td> Book Cover:</td>
<td> <input type="file" id="image" name="image"> </td>
</tr>
<tr>
<td> Is this a one-shot or series? (Y or N):</td>
<td> <input type="text" name="series" id="series"> </td>
</tr>
<tr>
<td></td>
<td>
<input type="submit" value="submit">
<input type="reset" value="Reset">
</td>
</tr>
</table>
</form>
</body>
</html>