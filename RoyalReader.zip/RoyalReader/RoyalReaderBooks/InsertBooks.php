<!DOCTYPE HTML>
<html>
<head>
<title>Enter Form for Book Store</title>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
        <link href="RoyalReadHomePage.css" rel="stylesheet" type="text/css">
</head>
<body>
 <!--Top Image Banner-->
 <div class="ImageFile">
    <h1 style="text-align: center">Royal Reader Book Store</h1>
  </div>
  <!--Top Image Banner Ends-->
 <!-- Navigation Bar Starts -->
  <div id="container">
  <ul id="nav">
  <li class="odd"><a href="../RoyalReaderHomePageL.php">Home Page</a></li>
  <li class="even"><a href="EnterBooks.php">Add a New Book</a></li>
  <li class="odd"><a href="DisplayBooks.php">RoyalReader Catalog</a></li>
  <li class="even"><a href="../SimpleBooks/index.php">Manual Shopping Cart</a></li>
</ul>
</div>
<center><h2>Insert Books</h2></center>
<br>

<?php
include("DBConnection.php");

//$royalreadnumber=$_POST["royalreadnumber"];
$title=$_POST["title"];
$author=$_POST["author"];
$pubdate=$_POST["pubdate"];
$price=$_POST["price"];
$synopsis=$_POST["synopsis"];
$publisher=$_POST["publisher"];
$image=$_POST["image"];
$series=$_POST["series"];

$query = "insert into royalreaderbooks(royalreadnumber, title, author, pubdate, price, synopsis, publisher, image, series)
 values('null', '$title', '$author', '$pubdate', '$price', '$synopsis', 
 '$publisher', '$image', '$series')"; //Insert query to add book details into the book table
$result = mysqli_query($db,$query);
?>

<h3> Book information is inserted successfully </h3>

<a href="SearchBooks.php"> To search for the Book information click here </a>

</body>
</html>