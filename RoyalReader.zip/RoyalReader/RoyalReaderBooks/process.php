<?php

    session_start();

$mysqli = new mysqli('localhost', 'root', "", 'royalreader') or die(mysqli_error($mysqli));

    $id = 0;
    $update = false;
    $title = '';
    $author = '';
    $pubdate = '';
    $price = '';
    $synopsis = '';
    $publisher = '';
    $image = '';
    $genre = '';
    $series = '';

?>