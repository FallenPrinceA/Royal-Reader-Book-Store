<?php
include 'functions.php';
// Connect to MySQL
$pdo = pdo_connect_mysql();
// MySQL query that selects all the polls and poll answers
$stmt = $pdo->query('SELECT p.*, GROUP_CONCAT(pa.title ORDER BY pa.id) AS answers FROM polls p LEFT JOIN poll_answers pa ON pa.poll_id = p.id GROUP BY p.id');
$polls = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?=template_header('Polls')?>

<div class="content home">
    <!--Top Image Banner-->
  <div class="ImageFile">
    <h1 style="text-align: center">Welcome to Royal Readers Polling Booth</h1>
  </div>
  <!--Top Image Banner Ends-->
    <!-- Navigation Bar Starts -->
  <div id="container">
  <ul id="nav">
  <li class="odd"><a href="../AuthorRegistry/index.php">Author Registry</a></li>
  <li class="even"><a href="../RoyalReaderBooks/DisplayBooks.php">Book Store</a></li>
  <li class="odd"><a href="index.php">Polls</a></li>
  <li class="even"><a href="../RoyalReaderContact.php">Contact</a></li>
  <li class="odd"><a href="#">Support The Site</a></li>
  <li class="even"><a href="../RoyalReaderNotepad/index.php">Notepad</a></li>
</ul>
<div id="work">
</div>
  <!-- Navigation Bar Ends -->

	<h2>Royal Reader Polls</h2>
	<p>Welcome to Royal Reader Polls. Interact with other authors or readers below using the poll system below.</p>
	<a href="create.php" class="create-poll">Create Poll</a>
	<table>
        <thead>
            <tr>
                <td>#</td>
                <td>Title</td>
				<td>Answers</td>
                <td></td>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($polls as $poll): ?>
            <tr>
                <td><?=$poll['id']?></td>
                <td><?=$poll['title']?></td>
				<td><?=$poll['answers']?></td>
                <td class="actions">
					<a href="vote.php?id=<?=$poll['id']?>" class="view" title="View Poll"><i class="fas fa-eye fa-xs"></i></a>
                    <a href="delete.php?id=<?=$poll['id']?>" class="trash" title="Delete Poll"><i class="fas fa-trash fa-xs"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?=template_footer()?>