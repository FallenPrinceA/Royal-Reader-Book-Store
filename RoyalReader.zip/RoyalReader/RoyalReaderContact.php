<php?
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Contact Us Page</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="rrcontactform.css" >
        <script src="form.js"></script>
    </head>
    <body >
        <div class="container">
           
          <div class="ImageFile">
    <h1 style="text-align: center">RoyalReader's Front Desk</h1>
  </div>
          <!-- Form Started -->
          <label for="Category">Category</label>
    <select id="category" name="category">
      <option value="Account">Account</option>
      <option value="Sponsorship Opportunity">Sponsorship Opportunity</option>
      <option value="Community">Community</option>
      <option value="Report a User">Report a User</option>
      <option value="Question">Question</option>
      <option value="Comment">Let us know what you think</option>
      <option value="Payment">Payment</option>
      <option value="Technical">Technical Difficulties</option>
    </select>
            <div class="container form-top">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12">
                        <div class="panel panel-danger">
                            <div class="panel-body">
                                <form id="reused_form">
                                    <div class="form-group">
                                        <label><i class="fa fa-user" aria-hidden="true"></i> UserName</label>
                                        <input type="text" name="name" class="form-control" placeholder="Enter Username or Guest Name" required autofocus>
                                    </div>
                                    <div class="form-group">
                                        <label><i class="fa fa-envelope" aria-hidden="true"></i> Email</label>
                                        <input type="email" name="email" class="form-control" placeholder="Enter Email Address" required autofocus>
                                    </div>
                              <label for="files">Attachments</label>
                            <input type="file" id="files" multiple="multiple" name="files"/>
                            <p class="help-block"> Select one or more files to upload. </p>
                                    <div class="form-group">
                                        <label><i class="fa fa-comment" aria-hidden="true"></i> Message</label>
                                        <textarea rows="5" name="message" class="form-control" placeholder="Type Your Message" required autofocus></textarea>
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-raised btn-block btn-danger">Submit &rarr;</button>
                                    </div>
                                </form>
                                <div id="error_message" style="width:100%; height:100%; display:none; ">
                                    <h4>
                                        Error
                                    </h4>
                                    Sorry there was an error sending your form. 
                                </div>
                                <div id="success_message" style="width:100%; height:100%; display:none; ">
<h2>Success! Your Message was Sent Successfully.</h2>
</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Form Ended -->
        </div>
    </body>
</html>
?>