<?php require_once 'authController.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <Meta charset="UTF-8">
        <!--Bootstrap 4 CSS-->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <!-- Other CSS File --->
        <link rel="stylesheet" href="registerandlogin.css" type="text/css">
        
        <title>Register</title>
</head>

    <body>
            <p>Register Today and Join the Royal Reader Community</p>

        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4 form-div">
                    <form action="signup.php" method="post">
                        <h3 class="text-center">Register</h3>
                        
                           <!-- Sign Up Error Message Starts -->
                    <?php if(count($errors) > 0 ): ?>
                        <div class="alert alert-danger">
                            <?php foreach($errors as $error): ?>
                            <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                        <!--Sign up Error Message Ends -->
                        
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" name="username" value="<?php echo $username; ?>" class="form-control form-control-lg">
                        </div>
                         
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" name="email" value="<?php echo $email; ?>" class="form-control form-control-lg">
                        </div>
                        
                         <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" class="form-control form-control-lg">
                        </div>
                        
                         <div class="form-group">
                            <label for="passwordConf">Confirm Password</label>
                            <input type="password" name="passwordConf" class="form-control form-control-lg">
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" name="signup-btn" class="btn btn-primary btn-block btn-log">Sign Up</button>
                        </div>
                        
                        <p class="text-center">Already a member? <a href="login.php">Sign In</a></p>
                        
                        
                        
                        
                    </form>
                
                </div>
        </div>
    </div>
        
</body>
</html>