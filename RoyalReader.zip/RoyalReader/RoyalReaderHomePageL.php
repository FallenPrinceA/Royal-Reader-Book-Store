<? php
    require_once 'controllers/authController.php';

//verify user using token
if (isset($_Get['token'])){
    $token = $_GET['token'];
    verifyUser($token);
}

if(!isset($_SESSION['id']){
header('location: RoyalReaderHomePage.html');    
    exit();
}

<!doctype html>

<html lang="en">

<head>
  <meta charset="utf-8">

  <title>Royal Reader's Logged In Home Page</title>
  <meta name="description" content="Royal Reader's Home Page">
  <meta name="author" content="FrontSite">

  <link href="RoyalReadHomePage.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="registerandlogin.css" type="text/css">
 
  <!--[if IE]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

</head>
<body>

  <!--Top Image Banner-->
  <div class="ImageFile">
    <h1 style="text-align: center">Welcome to Royal Readers</h1>
  </div>
  <!--Top Image Banner Ends-->
 <!-- Navigation Bar Starts -->
  <div id="container">
<ul id="nav">
  <li class="odd"><a href="AuthorRegistry/index.php">Author Registry</a></li>
  <li class="even"><a href="RoyalReaderBooks/EnterBooks.php">Book Store</a></li>
  <li class="odd"><a href="RoyalReaderpoll/index.php">Polls</a></li>
  <li class="even"><a href="RoyalReaderContact.php">Contact</a></li>
  <li class="odd"><a href="#">Support The Site</a></li>
  <li class="even"><a href="RoyalReaderNotepad/index.php">Notepad</a></li>
</ul>
<div id="work">
</div>
  <!-- Navigation Bar Ends -->

<!-- Successful Logged In Home Page -->

<div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4 form-div login">
                    <div class="alert alert-success">
                        You have successfully logged in!
                    </div>
                    
                    <h3>Welcome</h3>
                    
                    <a href="RoyalReaderHomePage.html?logout=1" class="logout">logout</a>
                    
                    <div class="alert alert-warning">
                        You need to verify your account.
                        Sign in to your email account and click on the verification link we just emailed
                    </div>
                    
                    <button class="btn btn-block btn-lg btn-primary">Already Verified</button>
                
                </div>
        </div>
    </div>

<!--Successful logged in ends -->
    

<!-- Main Paragraph -->
<div id="text">
<h1>Hello welcome to Royal Readers</h1>
    
<p>The best site for all your e-book needs. Royal Readers is a business created with the sole purpose of helping indie Authors connect with their audience, to set their own price, and to help them grow. From horror to mystery and romance to adventure, Royal Readers is for all fictional and non-fiction works that you would like to develop for your fanbase. Unlike other e-book sites, this site is meant to work not only as a e-book retailer but also as a social media site to connect authors to a fanbase. Grow your following, communicate in the forums, and share your status, your projects, and your goals for the future.Think of Royal Reader as your new home.</p>
</div>
</div>
  <!-- Main paragraph Ends -->
  <ol>
        <div id="art">
        <li>Explore: Find interesting new worlds and stories that will change your life</li>
          </div>
        <div id="art2">
        <li>Create: Create your own amazing stories and worlds that you and your readers and fans will enjoy</li>
        </div>
        <div id="art3">
        <li>Grow: Grow your own fanbase and your audience, connect your other social media accounts and make Royal Readers your new home for all your writing needs.</li>
      </div>
    </ol>
        
   <!--Story of the Week Bulletin-->
      <table cellpadding="2" cellspacing="2"
        style="float: left; border: 1px solid purple; margin-top: 1em; vertical-align: top; width: 120px;">
        <tr>
          <td
            style="margin: 0; background-color: black; font-size: 120%; font-weight: bold; text-align: center; color:#87ceeb; padding:0.2em 0.4em;">
            Story of the Week
          </td>
        </tr>
        <tr>
          <td>
            <div class="center">
              <div class="floatnone"><a
                  href="https://res.cloudinary.com/fallenprincebelial/image/upload/v1580944209/Royal%20Readers%20Images/Book_Cover_ptqxm2.jpg"
                  class="image image-thumbnail"><img
                    src="https://res.cloudinary.com/fallenprincebelial/image/upload/v1580944209/Royal%20Readers%20Images/Book_Cover_ptqxm2.jpg"
                    alt="1basara" class="lzy lzyPlcHld " data-image-key="1basara.jpg" data-image-name="1basara.jpg"
                    data-src="https://vignette.wikia.nocookie.net/dxdfanon/images/3/34/1basara.jpg/revision/latest?cb=20160727234025"
                    width="250" height="306"
                    onload="if(typeof ImgLzy===&#39;object&#39;){ImgLzy.load(this)}"><noscript><img
                      src="https://vignette.wikia.nocookie.net/dxdfanon/images/3/34/1basara.jpg/revision/latest?cb=20160727234025"
                      alt="1basara" class="" data-image-key="1basara.jpg" data-image-name="1basara.jpg" width="250"
                      height="306"></noscript></a></div>
            </div>
            <a href="https://stephenking.fandom.com/wiki/Carrie" title="Carrie by Stephen King">Carrie by Stephen
              King</a>(published: April 5th, 1974)<i> is a book about a girl who after awakening her psychic powers must
              not only confront her inner demons and dark family history but also her abusive mother and school bullies.
              After a prank gone wrong she has a night that she will never forget</i> <br />
            <center>- To learn more about the Author and his other stories click here<b> <a
                  href="https://en.wikipedia.org/wiki/Stephen_King" title="Author:Stephen King">Stephen King</a></b>
            </center>
          </td>
        </tr>
      </table>
      <!--Story of the Week bulletin Ends-->

     <iframe width="750" height="750" src="https://www.youtube.com/embed/f_Bh-yNpUpI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</body>
</html>