<?php

define('EMAIL', 'royalreader138@gmail.com');
define('PASSWORD', '@Pokemon64/7');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'royalreader');
?>