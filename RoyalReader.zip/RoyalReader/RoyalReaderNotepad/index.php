<!DOCTYPE html>
<html>
    <head>
        <title>Index for CRUD Notepad</title>
        <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
        <link href="RoyalReadHomePage.css" rel="stylesheet" type="text/css">
 
    </head>
    <body>
        <!--Top Image Banner-->
  <div class="ImageFile">
    <h1 style="text-align: center">Royal Reader Notepad</h1>
  </div>
  <!--Top Image Banner Ends-->
 <!-- Navigation Bar Starts -->
  <div id="container">
  <ul id="nav">
  <li class="odd"><a href="../AuthorRegistry/index.php">Author Registry</a></li>
  <li class="even"><a href="../RoyalReaderBooks/DisplayBooks.php">Book Store</a></li>
  <li class="odd"><a href="../RoyalReaderpoll/index.php">Polls</a></li>
  <li class="even"><a href="../RoyalReaderContact.php">Contact</a></li>
  <li class="odd"><a href="#">Support The Site</a></li>
  <li class="even"><a href="index.php">Notepad</a></li>
</ul>
<div id="work">
</div>
  <!-- Navigation Bar Ends -->
      
      <p>Hi and welcome to the RoyalReader notepad, have any books you would like to save or archive in our records or books you want to recommend to other readers? Save them in our database below and you can even update them when neccessary.</p>
        <?php require_once 'process.php'; ?>
        
        <?php
        
        if (isset($_SESSION['message'])): ?>
        
        <div class="alert alert-<?=$_SESSION['msg_type']?>">
            
            <?php
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            ?>
        </div>
        <?php endif ?>
        <div class="container">
        <?php
            $mysqli = new mysqli('localhost', 'root', "", 'royalreader') or die(mysqli_error($mysqli));
            $result = $mysqli->query("SELECT * FROM royalreadernotepad") or die($mysqli->error);
        ?>
        <div class="row justify-content-center"?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Published Date</th>
                        <th colspan="2">Action</th>
                    </tr>  
                </thead>
        <?php
                while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['title'];?></td>
                    <td><?php echo $row['author'];?></td>
                    <td><?php echo $row['pubdate'];?></td>
                    <td>
                        <a href="index.php?edit=<?php echo $row['id']; ?>"
                            class="btn btn-info">Edit</a>
                        <a href="process.php?delete=<?php echo $row['id']; ?>"
                           class="btn btn-danger">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </table> 
        </div>
        <?php
            function pre_r( $array ){
                echo '<pre>';
                print_r($array);
                echo '</pre>';
            }
        ?>
        
        <div class="row justify-content-center">
        <form action="process.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="form-group">
                <label>Title</label>
                <input type="text" name="title" class="form-control" value="<?php echo $title; ?>" placeholder="Enter the Book Title">
            </div>
            <div class="form-group">
                <label>Author Name</label>
                <input type="text" name="author" class="form-control" value="<?php echo $author; ?>" placeholder="Enter the author Name">
            </div>
            <div class="form-group">
                <label>Published Date</label>
                <input type="date" name="pubdate" class="form-control" value="<?php echo $pubdate; ?>" value="Enter the published date">
            </div>
            <div class="form group">
            <?php
                if ($update == true):
            ?>
                 <button type="submit" class="btn btn-info" name="update">Update</button> 
            <?php else: ?>
                <button type="submit" class="btn btn-primary" name="save">Save</button>    
            <?php endif; ?>
            </div>
        </form>
        </div>
        </div>
    </body>
