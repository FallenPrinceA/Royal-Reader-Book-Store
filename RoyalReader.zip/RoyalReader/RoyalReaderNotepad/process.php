<?php

    session_start();

$mysqli = new mysqli('localhost', 'root', "", 'royalreader') or die(mysqli_error($mysqli));

    $id = 0;
    $update = false;
    $title = '';
    $author = '';
    $pubdate = '';

if (isset($_POST['save'])){
    $title = $_POST['title'];
    $author = $_POST['author'];
    $pubdate = $_POST['pubdate'];
    
    $mysqli->query("INSERT INTO royalreadernotepad (title, author, pubdate) VALUES('$title', '$author', '$pubdate')") or die($mysqli->error);
    
    $_SESSION['message'] = "Record has been saved!";
    $_SESSION['msg_type'] = "success";
    
    header("location: index.php");
}

if (isset($_GET['delete'])){
    $id = $_GET['delete'];
    $mysqli->query("DELETE FROM royalreadernotepad WHERE id=$id") or die($mysqli->error());
    
    $_SESSION['message'] = "Record has been deleted!";
    $_SESSION['msg_type'] = "danger";
    
    header("location: index.php");
}

if (isset($_GET['edit'])){
    $id = $_GET['edit'];
    $update = true;
    $result = $mysqli->query("SELECT * FROM royalreadernotepad WHERE id = $id") or die($mysqli->error());
    if (count($result)==1){
        $row = $result->fetch_array();
        $title = $row['title'];
        $author = $row['author'];
        $pubdate = $row['pubdate'];
    }
}

if (isset($_POST['update'])){
    $id = $_POST['id'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $pubdate = $_POST['pubdate'];
    
    $mysqli->query("UPDATE royalreadernotepad SET title='$title', author='$author', pubdate='$pubdate' WHERE id=$id") or
                    die($mysqli->error);
    
    $_SESSION['message'] = "Record has been updated";
    $_SESSION['msg_type'] = "warning";
    
    header('location: index.php');
}

?>