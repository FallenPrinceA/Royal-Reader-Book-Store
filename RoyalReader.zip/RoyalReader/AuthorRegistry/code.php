<?php
	
	class Authors {
		public $db;
		public function __construct() {
			// Mysql connection
			$this->db = new mysqli("localhost", "root","","royalreader");
		}

		// inserting data
        public function insert($penname, $email, $publisher, $gender) {
            // creating prepared statement
            $sql = $this->db->prepare("INSERT INTO tbl_authors VALUES(null,?, ?, ?, ?)");
            $sql->bind_param("ssss", $penname, $email, $publisher, $gender);
            return $sql->execute();
        }

		public function getData() {
			$data = array();
			$sql = $this->db->prepare("SELECT * FROM tbl_authors");
			$sql->execute();

			// fetch result
			$get_result = $sql->get_result();
			// fetching data and storing to array
			while($res = $get_result->fetch_object()) {
				$data[] = $res;
			}
			// return array
			return $data;
		}

		public function getAuthorById($id) {
			$data = array();
			$sql = $this->db->prepare("SELECT * FROM tbl_authors WHERE id = ?");
			$sql->bind_param('i', $id);
			$sql->execute();

			// fetch result
			$get_result = $sql->get_result();
			// fetching data and storing to array
			$res = $get_result->fetch_object();
			return $res;
		}

		// updating data
		public function updateAuthorById($data) {
            var_dump($data) ;
			$sql = $this->db->prepare("UPDATE tbl_authors SET penname = ?, email = ?, publisher = ?, gender = ?  WHERE id = ?");
            //id, penname, email, publisher, gender
			$sql->bind_param('sssss', $data['penname'], $data['email'], $data['publisher'], $data['gender'], $data['id']);
			return $sql->execute();
		}

		// deleting data
		public function delete($id) {
			$return = false;
			$sql = $this->db->prepare("DELETE FROM tbl_authors WHERE id = ?");
			$sql->bind_param('i', $id);
			$sql->execute();

			// Count affected rows
			if($sql->affected_rows > 0) {
				$return = true;
			}
			return $return;
		}
	}