<?php

	include('code.php');

	$author = new Authors();
	
	if($author->insert($_POST['penname'], $_POST['email'], $_POST['publisher'], $_POST['gender'])) {
		header("location: index.php");
	} else {
		echo "Not save";
	}