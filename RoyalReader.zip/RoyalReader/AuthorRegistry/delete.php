<?php
	include 'code.php';
	$authors = new Authors();
	if($authors->delete(intval($_GET['id']))) {
		header("Location: index.php");
	} else {
		echo "No author found";
	}