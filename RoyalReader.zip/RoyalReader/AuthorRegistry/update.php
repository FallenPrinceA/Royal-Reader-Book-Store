<?php
	include 'code.php';
	$data = new Authors();
	$newData = $data->getAuthorById($_GET['id']);
	if(isset($_POST['update'])) {
		$author = array(
				'id'   	 => $_GET['id'],
				'penname' 	 => $_POST['penname'],
				'email'  	 => $_POST['email'],
                'publisher' => $_POST['publisher'],
                'gender'  	 => $_POST['gender']
			);
		if($data->updateAuthorById($author)) {
			echo "Author successfully Updated";
		} else {
			echo "Oops?! Something went wrong";
		}
	}
	unset($_POST['update']);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Update Registry</title>
     <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
        <link href="RoyalReadHomePage.css" rel="stylesheet" type="text/css">
</head>
<body>
    <!--Top Image Banner-->
<div class="ImageFile">
    <h1 style="text-align: center">Royal Reader Author Registry</h1>
  </div>
  <!--Top Image Banner Ends-->
 <!-- Navigation Bar Starts -->
  <div id="container">
  <ul id="nav">
  <li class="odd"><a href="index.php">Author Registry</a></li>
  <li class="even"><a href="../RoyalReaderBooks/DisplayBooks.php">Book Store</a></li>
  <li class="odd"><a href="../RoyalReaderpoll/index.php">Polls</a></li>
  <li class="even"><a href="../RoyalReaderContact.php">Contact</a></li>
  <li class="odd"><a href="#">Support The Site</a></li>
  <li class="even"><a href="../RoyalReaderNotepad/index.php">Notepad</a></li>
</ul>
<div id="work">
</div>
  <!-- Navigation Bar Ends -->
      <h1>Update The Registry by filling out the file below</h1>
	<form action="" method="POST">
		<input type="text" name="penname" placeholder="PenName" value="<?php echo $newData->penname; ?>" required=""><br />
		<input type="text" name="email" placeholder="Email" value="<?php echo $newData->email; ?>"><br />
        <input type="text" name="publisher" placeholder="Publisher" value="<?php echo $newData->publisher; ?>"><br />
		<select name="gender">
			<option <?php echo $newData->gender == "Male" ? "selected='true'" : ""; ?>>Male</option>
			<option <?php echo $newData->gender == "Female" ? "selected='true'" : ""; ?>>Female</option>
		</select><br />
		<button type="submit" name="update">Update</button>
		<a href='http://localhost:8080/RoyalReader/AuthorRegistry/index.php'>Home</a>
	</form>
</body>
</html>