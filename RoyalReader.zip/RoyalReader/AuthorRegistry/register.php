<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="logic.php" method="POST">
		<input type="text" name="penname" placeholder="PenName"><br />
		<input type="text" name="email" placeholder="Email"><br />
        <input type="text" name="publisher" placeholder="Publisher"><br />
		<select name="gender">
			<option>Male</option>
			<option>Female</option>
		</select><br />
		<button type="submit">Save</button>
	</form>
</body>
</html>