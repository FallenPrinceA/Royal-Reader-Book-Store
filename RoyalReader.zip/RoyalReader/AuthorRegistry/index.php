<!DOCTYPE html>
<html>
<head>
	<title>Author Registry</title>
    <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
        <link href="RoyalReadHomePage.css" rel="stylesheet" type="text/css">
</head>
<?php 
		include('code.php'); 
		$author = new Authors();
	?>
<body>
<!--Top Image Banner-->
<div class="ImageFile">
    <h1 style="text-align: center">Royal Reader Author Registry</h1>
  </div>
  <!--Top Image Banner Ends-->
 <!-- Navigation Bar Starts -->
  <div id="container">
<ul id="nav">
  <li class="odd"><a href="index.php">Author Registry</a></li>
  <li class="even"><a href="../RoyalReaderBooks/DisplayBooks.php">Book Store</a></li>
  <li class="odd"><a href="../RoyalReaderpoll/index.php">Polls</a></li>
  <li class="even"><a href="../RoyalReaderContact.php">Contact</a></li>
  <li class="odd"><a href="#">Support The Site</a></li>
  <li class="even"><a href="../RoyalReaderNotepad/index.php">Notepad</a></li>
</ul>
<div id="work">
</div>
  <!-- Navigation Bar Ends -->
  <h1>Welcome to the Royal Reader Author Registry</h1>
  <p>A place for authors to register to become our official readers in our database</p>

  <h2>Why is this important?</h2>
  <p>As the site grows, keeping track of all the readers will become much more difficult, so to make sure that we remember all of you, we want to record you in the database. This will allow us to delete stories from a individual author should the need arise also to remove fradulent stories or to get in contact with you should the need to rise. Think of this like our party list, where we keep track of whose invited and whose not. </p>
  <p>Simply fill out the form below with your information and we'll contact you via email when needed</p>
	<table border="1" cellpadding="10">
		<thead>
			<tr>
				<th>PenName</th>
				<th>Email</th>
                <th>Publisher</th>
				<th>Gender</th>
				<th colspan="2">Action</th>
			</tr>
		</thead>
		<tbody>
			<!-- extract object -->
			<?php foreach($author->getData() as $authors){ ?>
				<tr>
					<td><?php echo $authors->penname; ?></td>
					<td><?php echo $authors->email; ?></td>
                    <td><?php echo $authors->publisher; ?></td>
					<td><?php echo $authors->gender; ?></td>
					<td><a href="update.php?id=<?php echo $authors->id; ?>">Update</a></td>
					<td><a href="delete.php?id=<?php echo $authors->id; ?>" onclick="return confirm('Are you sure you want to delete?')">Delete</a></td>
				</tr>
			<?php } ?>
		</tbody>
		<tfoot>
			<tr>
				<td colspan="5">
					<a href="register.php">Register</a>
				</td>
			</tr>
		</tfoot>
	</table>
</body>
</html>